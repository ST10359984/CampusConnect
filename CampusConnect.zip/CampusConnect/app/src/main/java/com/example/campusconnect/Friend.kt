package com.example.campusconnect

data class Friend(
    val uid: String? = null,
    val name: String? = null,
    val email: String? = null,
    val profileImage: String? = null
)